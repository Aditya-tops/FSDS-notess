print("Step 1: Importing the libraries")

from crewai import Agent
from crewai import Task
from crewai import Crew
from crewai import LLM






print("Step 2: Configure the llm")

llm = LLM(
    model = "ollama/llama3.2",
    base_url = "http://localhost:11434"
)






print("Step 3.1: Create Researcher Agent")

researcher = Agent(
    role = "Researcher",
    goal = "Gather information about a given topic.",
    backstory = "A detail-oriented AI skilled in finding accurate information.",
    verbose = True,
    allow_delegation = False
)









print("Step 3.2: Create Writer Agent")

writer = Agent(
    role = "Writer",
    goal = "Summarize information into a concise and readable format.",
    backstory = "A creative AI that enjoys writing clear and engaging summaries.",
    verbose = True,
    allow_delegation = False
)






print("Step 4.1: Create Research Task")

research_task = Task(
    description = "Find key details about the benefits of AI in healthcare.",
    agent = researcher,
    expected_output = "A list of key benefits of AI in healthcare."
)




print("Step 4.2: Create Writing Task")

writing_task = Task(
    description = "Summarize the research findings into a short article.",
    agent = writer,
    expected_output = "A well-structured summary of AI's benefits in healthcare."
)





print("Step 5: Create a Crew")

crew = Crew(
    agents = [researcher, writer],
    tasks = [research_task, writing_task],
    verbose = True
)





print("Step 6: Run the Crew")

response = crew.kickoff()





print("Step 7: Check the Response")

print(response)


