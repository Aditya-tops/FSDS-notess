print("Step 1: Importing the libraries")

from crewai import Agent
from crewai import Task
from crewai import Crew
from crewai import LLM




print("Step 2: Configure the llm")

llm = LLM(
    model = "ollama/llama3.2",
    base_url = "http://localhost:11434"
)




print("Step 3: Create Agent")

simple_agent = Agent(
    role = "Friendly AI",
    goal = "Respond with a simple greeting.",
    backstory = "You are a helpful AI that loves saying hello.",
    verbose = True
)




print("Step 4: Define Tasks")

greeting_task = Task(
    description = "Say 'Hello, World!'",
    agent = simple_agent,
    expected_output = "A friendly greeting."
)



print("Step 5: Create a Crew")

crew = Crew(
    agents = [simple_agent],
    tasks = [greeting_task],
    verbose = True
)





print("Step 6: Kickoff the Crew")

response = crew.kickoff()



print("Step 7: Check the Response")

print(response)


