print("Step 1: Importing the libraries")

from crewai import Agent
from crewai import Task
from crewai import Crew
from crewai import LLM






print("Step 2: Configure the llm")

llm = LLM(
    model = "ollama/llama3.2",
    base_url = "http://localhost:11434"
)






print("Step 3: Create Agent")

senior_technical_writer = Agent(
    role = "Senior Technical Writer",
    goal = """Craft clear, engaging, and well-structured technical content based on research findings""",
    backstory = """You are an experienced technical writer with expertise in simplifying complex concepts, structuring content for readability, and ensuring accuracy in documentation.""",
    llm = llm,
    verbose = True
)





print("Step 4: Create Task")

writing_task = Task(
    description = """Write a well-structured, engaging, and technically accurate article on {topic}.""",
    agent = senior_technical_writer, 
    expected_output = """A polished, detailed, and easy-to-read article on the given topic."""
)






print("Step 5: Create a Crew ")

crew = Crew(
    agents = [senior_technical_writer],
    tasks = [writing_task],
    verbose = True
)




print("Step 6: Run the Crew")

response = crew.kickoff(inputs = {"topic" : "AI Agents"})




print("Step 6: Check the Response")

print(response)
