print("Topic: train_test_split: LogisticRegression")
print()


print("Step 1: Importing the libraries")

from sklearn.datasets import load_digits
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split





print("Step 2: Loading the dataset")

digits = load_digits()




print("Step 3: Data preparation")

X = digits.data
y = digits.target





print("Step 4: Splitting the dataset")

X_train, X_test, y_train, y_test = train_test_split(
    X, 
    y, 
    test_size = 0.3
)




print("Step 5: Model creation")

model1 = LogisticRegression(
    solver = 'lbfgs', 
    max_iter = 3000
)



print("Step 6: Model training")

model1.fit(X_train, y_train)





print("Step Spl: Checking the score")

print()
print(model1.score(X_test, y_test))
