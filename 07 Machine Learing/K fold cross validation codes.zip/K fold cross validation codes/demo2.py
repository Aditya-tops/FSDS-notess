print("Topic: train_test_split: SVC")
print()


print("Step 1: Importing the libraries")

from sklearn.svm import SVC
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split





print("Step 2: Loading the dataset")

digits = load_digits()




print("Step 3: Data preparation")

X = digits.data
y = digits.target




print("Step 4: Splitting the dataset")

X_train, X_test, y_train, y_test = train_test_split(
    X, 
    y, 
    test_size = 0.3
)



print("Step 5: Model creation")

model2 = SVC()




print("Step 6: Model training")

model2.fit(X_train, y_train)



print("Step Spl: Checking the score")

print()
print(model2.score(X_test, y_test))