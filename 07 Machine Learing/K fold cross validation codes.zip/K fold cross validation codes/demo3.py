print("Topic: train_test_split: RandomForest")
print()




print("Step 1: Importing the libraries")

from sklearn.datasets import load_digits
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split




print("Step 2: Loading the dataset")

digits = load_digits()




print("Step 3: Data preparation")

X = digits.data
y = digits.target




print("Step 4: Splitting the dataset")

X_train, X_test, y_train, y_test = train_test_split(
    X, 
    y, 
    test_size = 0.3
)



print("Step 5: Model creation")

model3 = RandomForestClassifier( n_estimators = 40)





print("Step 6: Model training")

model3.fit(X_train, y_train)




print("Step Spl: Checking the score")

print()
print(model3.score(X_test, y_test))
