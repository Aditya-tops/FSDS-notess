print("Topic: K fold cross validation: LogisticRegression")
print()



print("Step 1: Importing the libraries")

from sklearn.datasets import load_digits
from sklearn.model_selection import cross_val_score
from sklearn.linear_model import LogisticRegression



print("Step 2: Loading the dataset")

digits = load_digits()




print("Step 3: Data preparation")

X = digits.data
y = digits.target




print("Step 4: Splitting the dataset: K fold cross val")




print("Step 5: Model creation")

model1 = LogisticRegression(
    solver = 'lbfgs', 
    max_iter = 3000
)

scores1 = cross_val_score(
    model1, 
    X, 
    y, 
    cv = 3
)



print("Step Spl: Checking the score")

print()
print(scores1)

