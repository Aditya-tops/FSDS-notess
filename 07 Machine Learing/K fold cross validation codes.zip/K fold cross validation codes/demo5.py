print("Topic: K fold cross validation: SVC")
print()





print("Step 1: Importing the libraries")

from sklearn.svm import SVC
from sklearn.datasets import load_digits
from sklearn.model_selection import cross_val_score






print("Step 2: Loading the dataset")

digits = load_digits()






print("Step 3: Data preparation")

X = digits.data
y = digits.target







print("Step 4: Splitting the dataset: K fold cross val")




print("Step 5: Model creation")


model2 = SVC()

scores2 = cross_val_score(model2, X, y, cv = 3)





print("Step Spl: Getting the score")
print()
print(scores2)






