print("Topic: K fold cross validation: All models")
print()





print("Step 1: Importing the libraries")

import numpy as np
from sklearn.svm import SVC
from sklearn.datasets import load_digits
from sklearn.model_selection import cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression






print("Step 2: Loading the dataset")

digits = load_digits()







print("Step 3: Data preparation")

X = digits.data
y = digits.target






print("Step 4: Splitting the dataset: K fold cross val")


print("Step 5: Creating models")

model1 = LogisticRegression(
    solver = 'lbfgs', 
    max_iter = 5000
)

model2 = SVC()

model3 = RandomForestClassifier()


scores1 = cross_val_score(model1, X, y, cv = 3)
scores2 = cross_val_score(model2, X, y, cv = 3)
scores3 = cross_val_score(model3, X, y, cv = 3)


print()
print("LogisticRegression:", np.average(scores1)*100)
print("SVC:", np.average(scores2)*100)
print("RandomForestClassifier:", np.average(scores3)*100)
