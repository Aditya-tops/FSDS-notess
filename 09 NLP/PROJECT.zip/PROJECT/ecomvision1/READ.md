PROJECT NAME	:	ecomvision1
OBJECTIVE		:	ecommerce data science project
TECHNOLOGY		: 	numpy, pandas
DATE			:	26/05/2023

STRUCTURE		:	ecomvision1/src
					ecomvision1/requirements.txt
					ecomvision1/READ.md
					
					ecomvision1/src/ecom
					ecomvision1/src/run_ecom.py
					
					ecomvision1/src/ecom/utilities
					ecomvision1/src/ecom/__init__.py

					ecomvision1/src/ecom/utilities/tools.py
					ecomvision1/src/ecom/utilities/__init__.py
					


requirements.txt:	To specify all required libraries
Run				:	pip install -r requirements.txt

