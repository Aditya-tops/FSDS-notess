Project Name
This is ecom project

Project Status: Running
Project objective: Data Science ecom version

Technologies
numpy
pandas
