import pandas as pd
import numpy as np


def get_transactions(transaction_items):
    """Return a Pandas DataFrame of transactions from a Pandas DataFrame of transaction items.

    Args:
        transaction_items (object): DataFrame containing order_id, sku, quantity, unit_price, customer_id, order_date

    Returns:
        transactions: Pandas DataFrame containing transactions
    """

    transaction_items = transaction_items.sort_values(by=['order_date'], ascending=True)
    
    transactions = transaction_items.groupby('order_id').agg(order_date=('order_date', 'max'))
      
    return transactions


