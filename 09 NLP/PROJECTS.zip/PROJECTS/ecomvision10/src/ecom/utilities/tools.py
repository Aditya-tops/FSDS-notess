import pandas as pd
import os

def load_data():
    """Load the Online Retail dataset of transaction items and format for use within EcommerceTools functions.

    :return: Pandas dataframe.
    """
    url = "https://raw.githubusercontent.com/databricks/Spark-The-Definitive-Guide/master/data/retail-data/all/online-retail-dataset.csv"
    
    df = pd.read_csv(url)

    return df
    
def process_data():
    """Process raw Online Retail dataset of transaction items and format for use within EcommerceTools functions.

    :return: Pandas dataframe.
    """
        
    raw_file = "C:\\Users\\Nireekshan\\Desktop\\PROJECTS\\ecomvision10\\data\\raw\\transaction_items.csv"
    
    # Renaming colulmns, reading order_date with parse_dates
    
    cols = ['order_id', 'sku', 'description', 'quantity', 'order_date', 'unit_price', 'customer_id', 'country']
    
    df = pd.read_csv(raw_file, names = cols, skiprows = 1, parse_dates=['order_date'])
    df['quantity'] = pd.to_numeric(df['quantity'])
    df['line_price'] = df['unit_price'] * df['quantity']
    
    return df