import pandas as pd

def load_data():
    """Load the Online Retail dataset of transaction items.

    :return: Pandas dataframe.
    """
       
    url = "https://raw.githubusercontent.com/databricks/Spark-The-Definitive-Guide/master/data/retail-data/all/online-retail-dataset.csv"
        
    df = pd.read_csv(url)
    
    return df
    
