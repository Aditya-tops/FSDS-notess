# without using __init__.py file

from ecom.utilities.tools import load_data

# =========================
# Loading data
# =========================

print("1. Loading data")
print()

transaction_items = load_data()

print(transaction_items.head())
print()
print(transaction_items.shape)
print()
print(transaction_items.columns)
