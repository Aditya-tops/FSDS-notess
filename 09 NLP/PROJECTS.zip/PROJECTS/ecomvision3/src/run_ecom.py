# with using __init__.py file

from ecom import utilities

# =========================
# Loading data
# =========================

print("1. Loading data")
print()

transaction_items = utilities.load_data()

w = utilities.daniel()
print(w)

value = utilities.m1()
print(value)


'''
print(transaction_items.head())
print()
print(transaction_items.shape)
print()
print(transaction_items.columns)
'''
