# with using __init__.py file

from ecom import utilities














# ==================================================
# Loading data
# ==================================================

print("1. Loading data")

transaction_items = utilities.load_data()
print(transaction_items.head())















# ==================================================
# Creating transaction_items.csv in raw folder
# ==================================================

directory = "C:\\Users\\Nireekshan\\Desktop\\PROJECTS\\ecomvision5\\data\\raw"

    
transaction_items.to_csv("{}\\transaction_items.csv".format(directory))

print()
print("transaction_items.csv file created in {} directory".format(directory))






















# ==================================================
# Processing transaction_items data
# ==================================================

print("1. Loading RAW data")

process_trans_items = utilities.process_data()
print(process_trans_items.head())


















# ==================================================
# Creating transaction_items.csv in raw folder
# ==================================================

directory = "C:\\Users\\Nireekshan\\Desktop\\PROJECTS\\ecomvision5\\data\\processed"

    
process_trans_items.to_csv("{}\\process_trans_items.csv".format(directory))

print()
print("process_trans_items.csv file created in {} directory".format(directory))


