import pandas as pd
import numpy as np


def get_transactions(transaction_items):
    """Return a Pandas DataFrame of transactions from a Pandas DataFrame of transaction items.

    Args:
        transaction_items (object): DataFrame containing ordered DataFrame based on order_date column

    Returns:
        transactions: Pandas DataFrame containing transactions
    """

    transaction_items = transaction_items.sort_values(by=['order_date'], ascending=True)
    
    return transaction_items